# chipper-node-miner-release

Release Note

### for Windows 10, Windows 11

- din-chipper-node-app-windows-amd64.exe

### for linux (Ubuntu, Debian)

- din-chipper-node-cli-linux-arm64
- din-chipper-node-cli-linux-amd64

### for Mac with Intel CPU

- din-chipper-node-cli-darwin-amd64


### for Mac with M1, M2, M3 CPU

- din-chipper-node-cli-darwin-arm64



## CLI:
```
./din-chipper-node-cli-xxxx   --license=./xx.license
```
